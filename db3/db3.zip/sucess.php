<?php
	session_start();
	echo "Congratulations! {$_POST[first_name]} you registered sucessfully!"

?>		
<html>
<head>
	<title></title>
</head>
</body>
	<a href='process.php'>LOG OFF! </a>;		
</body>
</html>	