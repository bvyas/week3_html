<html>
<head>
	<title>Registration</title>
	<style type="text/css">
		.Registration{
			text-align: left;
			border: 1px solid silver;
			padding-left: 30px;
			width: 300px;
		}
		.Registration h6{
			text-align: center;
		}
	</style>
</head>
<body>

	<div class ="Registration">
		<h4>Wecome to the Registration Home Page</h4>
		<form acton = "/Student/index" method="post">
			First Name  <input type ="text" value" ">
			<p>Last Name <input type ="text" value" "></p>
			<p>Email Address <input type ="text" value" "></p>
			<p>Password <input type ="password" value" "></p>
			<p>Confirm Password <input type ="password" value" "></p>
			<p><h6><button type="submit" value="Register">Register</button><h6></p>
		</form>
	</div>		
</body>
</html>