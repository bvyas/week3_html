<html>
<head>
	<title>Registration</title>
</head>
<body>

	<div id ="result">
		<?php
	 	//var_dump($register);
	 	echo "Congratulation you have registered sucessfully!"
	 	//foreach ($register as $num)
	 	 //{
	 		//echo "Frist names entered" .($num->FirstName). '<br>';
	 		//echo "Last names entered" .($num->LastName). '<br>';
	 		//echo "Email Addresses entered" .($num->EmailAddress). '<br>';
	 	//}	
	 	//var_dump($user);
	 	?>
	</div>
</body>
</html>