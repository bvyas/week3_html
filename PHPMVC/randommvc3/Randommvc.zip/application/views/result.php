<html>
<head>
	<title>Random Number</title>
</head>
<body>

	<div id ="result">
		<h4><?php echo "Random String is" .$mynum ?></h4>
	</div>	

</body>
</html>