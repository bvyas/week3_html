<html>
<head>
	<title>Product details</title>
</head>
<body>
<div class="order_details">
	<h4>Order ID #X;</h4>
	<p><h4>Customer Shipping info:</h4></p>
	<p><h4>name:xxx</h4></p>
	<p><h4>address:xxx</h4></p>
	<p><h4>city:xxx</h4></p>
	<p><h4>zip:xxx</h4></p>

	<p><h4>Customer billing info:</h4></p>
	<p><h4>name:xxx</h4></p>
	<p><h4>address:xxx</h4></p>
	<p><h4>city:xxx</h4></p>
	<p><h4>zip:xxx</h4></p>
</div>
<div id="order_desc">
	<table>
			<tr>
				<td>ID</td>
				<td>Item</td>
				<td>Price</td>
				<td>Quantity</td>
				<td>Total</td>
			</tr>
			<tr>			
				<td>$product->ID</td>
				<td>product->Item</td>
				<td>$product->Price</td>
				<td>$product->Quantity</td>
				<td>$product->Total</td>
				</tr>					
		</table>
</div>
<h5>Status:xxxx</h5>
<div id="diaplay">
	<h5>Sub Total:xxx</h5>
	<h5>Shipping:xx</h5>
	<h5>Total Price:xx</h5>
</div>		
</body>
</html>