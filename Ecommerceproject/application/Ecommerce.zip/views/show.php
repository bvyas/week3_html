<html>
<head>
	<title>Product Show</title>
	<style type="text/css">
	.detail_product{
		display: inline-block;
		vertical-align: top;
		width: 250px;
		height: 150px;
	}
	.description {
		display: inline-block;
		vertical-align: top;
		width: 150px;
		height: 300px;
	}
	#items h6{
		width: 500px;
		height: 100px;
	}
	#items h6{
		width: 150px;
		padding-top: 0px;
		margin-top: 0px;
		height: 100px;
		display: inline-block;
		text-align: left;
	}

	</style>
</head>
<body>
	<div class="detail_product">
		<h4>Black Belt for staff</h4>
		<img src = "assets/images/box.png" width="150" height="100">
		<br><img src = "assets/images/box.png" width="50" height="50">
		<img src = "assets/images/box.png" width="50" height="50">
		<img src = "assets/images/box.png" width="50" height="50">
	</div>
	<div class="description">
		<h6>is simply dummy text of the printing and typesetting 
			industry. Lorem Ipsum has been the industry's standard 
			dummy text ever since the 1500s, when an unknown printer 
			took a galley of type and scrambled it to make a type 
			specimen book. It has survived not only five centuries, 
			but also the leap into electronic typesetting, remaining 
			essentially unchanged. It was popularised in the 1960s 
			with the release of Letraset sheets containing Lorem Ipsum
			passages, and more recently with desktop publishing 
			software like Aldus PageMaker including versions of Lorem 
			Ipsum.</h6>

	<select>		 
		<option>1 $price</option>
		<option>2 $price</option>
		<option>3 $price</option>
		<option>4 $price</option>
	</select>
		<input type="hidden" name="buy" value="buy">
		<button type="submit" value ="Buy">Buy</button>	
	</div>
	<div id="items"
		<br><h5>Similar Items</h5>
		<h6><img src = "assets/images/box.png" width="50" height="50">black belt, $19.99</h6>
		<h6><img src = "assets/images/box.png" width="50" height="50">black belt, $19.99</h6>
		<h6><img src = "assets/images/box.png" width="50" height="50">black belt, $19.99</h6>
		<h6><img src = "assets/images/box.png" width="50" height="50">black belt, $19.99</h6
	</div>

</body>
</html>