<html>
<head>
	<title>Welcome to MVC</title>

<style type="text/css">
h3
{
	text-align: center;
	border: 1px solid black;
	padding: 30px 30px 30px 30px;
}
</style>
</head>
<body>

	<h3>The current time and date is<?php echo $mydate?>:</h3>

</body>
</html>
